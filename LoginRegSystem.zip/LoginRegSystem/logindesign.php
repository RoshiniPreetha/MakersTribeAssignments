<?php
// requiring connection for sign up code //
require_once("connection.php");
$error = "";
if(isset($_POST['login'])){
    $email = $_POST["email"];
    $pass = $_POST["password"];
      
        $email = stripcslashes($email);  
        $pass = stripcslashes($pass);  
        $email = mysqli_real_escape_string($conn, $email);  
        $pass = mysqli_real_escape_string($conn, $pass); 
        
        $query = "select * from users where email = '$email' and password = '$pass'";  
        $result = mysqli_query($conn, $query);  
        $row = mysqli_fetch_array($result, MYSQLI_ASSOC);  
        $count = mysqli_num_rows($result);  
          
        if($count != 0){ 
        header("Location: http://localhost/LoginRegSystem/welcome.php");
        }  
        else{ $error = "Invalid Login credentials!";
      }
    }
    ?> 


<!DOCTYPE html>
<html>
<head>
    
    <title>LoginPage</title>
    <!--Bootstrap  and css links ------------------------------------------------------------------------------------------------->

    <linsk rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.5.0/css/all.css" integrity="sha384-B4dIYHKNBt8Bc12p+WXckhzcICo0wtJAoU8YZTY5qE0Id1GSseTk6S+L3BlXeVIU" crossorigin="anonymous">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js"></script>
    <link rel="stylesheet" type="text/css" href="style.css">

    <!--end of bootstrap links---------------------------------------------------------------------------------------------------->
  
</head>
<body>
<!-- navbar code for login  ****************************************************************************************************-->
<nav class="navbar navbar-expand-md bg-dark navbar-dark sticky-top">
   <img src="logo.jpg" width="60px" height="60px" top="10px">
  <a class="navbar-brand" href="#">Makers Tribe</a>
  <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navb" aria-expanded="true">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div id="navb" class="navbar-collapse collapse hide">
    <ul class="navbar-nav">
      <li class="nav-item active">
        <a class="nav-link" href="http://localhost/LoginRegSystem/logindesign.php">Login</a>
      </li>
    </ul>

  </div>
</nav>
<!-- login box form code ------------------------------------------------------------------------------------------------------------>
<br>
<br>
<div class="login-box">
  <img src="avatar.png" class="avatar">

    <center style="color: red"><?php echo $error; ?></center>
    
        <form action="logindesign.php" method="post"> 

        
            
            <input class="form-control" type="email" id="email" name="email" placeholder="Email Address" required>
            
            <input class="form-control" type="password" id="password" name="password" placeholder="Password" required>

            <input class="btn btn-primary" type="submit" id="register" name="login" value="Login">

            <a href="http://localhost/LoginRegSystem/signupdesign.php">New User?</a>
    </form>
  
</div>
</body>
</html>
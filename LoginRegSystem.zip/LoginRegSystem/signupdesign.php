<?php
// requiring connection for sign up code //
require_once("connection.php");
$error="";

if(isset($_POST['signup']))
{

      $name=$_POST['name'];
      $email=$_POST['email'];
      $dob=$_POST['dob'];
      $password=$_POST['password'];
      $foi=$_POST['foi'];
      $ura=$_POST['ura'];

      $email = stripcslashes($email);
      $email = mysqli_real_escape_string($conn, $email);

      $query1="SELECT * from users where email = '$email'";
      $result = mysqli_query($conn, $query1);  
          $row = mysqli_fetch_array($result, MYSQLI_ASSOC);  
          $count = mysqli_num_rows($result);  
          
          
        if($count != 0){ 
        $error = "Email Address already exists! Please Login";
        }  
        else{ 
          $query2="INSERT INTO users(id, name, email, dob, password, foi, ura) VALUES ('','$name','$email','$dob','$password','$foi','$ura')";

        if (mysqli_query($conn, $query2)) {
            header("Location: http://localhost/LoginRegSystem/welcome.php");
        } else {
            echo "Error: " . mysqli_error($conn);
        }
        mysqli_close($conn);
    }
    }
?>



<!DOCTYPE html>
<html>
<head>
    
    <title>SignUpPage</title>

    <!--Bootstrap  and css links ------------------------------------------------------------------------------------------------->

    <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.5.0/css/all.css" integrity="sha384-B4dIYHKNBt8Bc12p+WXckhzcICo0wtJAoU8YZTY5qE0Id1GSseTk6S+L3BlXeVIU" crossorigin="anonymous">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js"></script>
    <link rel="stylesheet" type="text/css" href="style.css">
    
    <!--end of bootstrap links---------------------------------------------------------------------------------------------------->

</head>
<body>




<!-- navbar code for sign up ****************************************************************************************************-->

<nav class="navbar navbar-expand-md bg-dark navbar-dark sticky-top">
   <img src="logo.jpg" width="60px" height="60px" top="10px">
  <a class="navbar-brand" href="#">Makers Tribe</a>
  <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navb" aria-expanded="true">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div id="navb" class="navbar-collapse collapse hide">
    <ul class="navbar-nav">
      <li class="nav-item active">
        <a class="nav-link" href="http://localhost/LoginRegSystem/signupdesign.php">Sign Up</a>
      </li>
    </ul>

  </div>
</nav>



<!-- signup box form code ------------------------------------------------------------------------------------------------------------>
<br>
<br>
<div class="signup-box">
   <img src="avatar.png" class="avatar">
   <center style="color: red"><?php echo $error; ?></center>
   
    <form action="signupdesign.php" method="post"> 

            <input class="form-control" type="text" id="name" name="name" placeholder="Name" required>
            
            
            <input class="form-control" type="email" id="email" name="email" placeholder="Email Address" required>

            
            <input class="form-control" type = "text" id="dob" name="dob" placeholder="Date of Birth"  onfocus = "(this.type = 'date')" required>

            
            <input class="form-control" type="password" id="password" name="password" placeholder="Password" required>

            <input class="form-control" type="text" id="foi" name="foi"  placeholder="Field of Interest" required>
          
            <label>You are a </label><br>
            <input  type="radio" name="ura" id="student" value="Student" required><label for="student">Student</label><br>
            <input  type="radio" name="ura" id="professional" value="Professional" required><label for="professional">Professional</label>
            
            <input class="btn btn-primary" type="submit" id="register" name="signup" value="Sign Up">
            <a href="http://localhost/LoginRegSystem/logindesign.php">Already a User?</a>
    </form>
  
</div>
</body>
</html>